package CoreJava;
import java.util.*;
public class Ques15 
{


	public static void main (String[] args) 
        {
		
		Scanner sc = new Scanner (System.in);
		
		// taking input from user 
		
		System.out.println("Enter age");
		int age = sc.nextInt();
		
		System.out.println("Enter sex: M/F");
		int sex = sc.next().charAt(0);
		
		
                        if(age>18)

                         {

                          System.out.println("you are eligible to marry");

                            }

                                else
                        {

                               System.out.println("not eligible to marry");

                                        }

            }
	}
