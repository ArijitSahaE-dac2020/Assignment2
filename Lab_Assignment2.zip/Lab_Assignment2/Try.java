package Lab_Assignment2;
import java.util.*;
public class Try
{
    
{
  
   int rollNo;
   String Name;
   double marks;
  
   Student()
 {
   stud1=new student();
   rollNo= 25;
   name = "Ram";
}
   Student()
{
   stud2=new student();
   rollNo= 50;
   name = "Sham";
}

   {
      void put();
      System.out.println(RollNo +"rollNo");
       System.out.println(Name +"name");
    } 
     public static void main(String[] args)
{
  Student s=new Student();
  s.put();
   
  }

}