package Day1;
class PyramidPattern4
{
    public static void main (String args[])
    {
        for(int i=1 ; i<=9 ; i++)
		{
			for(int j=9 ; j>=i ; j--)
			{
				System.out.print("  ");
			}
			int c=1;
			for(int k=1 ; k<=i ; k++)
			{
				System.out.print(" "+c);
				c++;
				
			}
			c=i-1;
			for(int m=2 ; m<=i ; m++ )
			{
				System.out.print(" "+c);
				c--;
			}
			System.out.println();
		}
	}
}