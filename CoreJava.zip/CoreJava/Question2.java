package CoreJava;
import java.util.*;
class  Question2
{
   public static void main(String args[])
   {
       Scanner sc = new Scanner(System.in);
      int rollno = sc.nextInt();
       int rollNo=100;
        System.out.println("roll  no="+rollNo);
       
   }
}