package Lab_Assignment2;
import java.util.*; 

  
class  Ques5
{ 
// Function to find sum of series 
    public static void main(String a[])

{ 
    Scanner sc = new Scanner(System.in);
    int num1= sc.nextInt();
    int num2= sc.nextInt();
    int flag=0;
    for(int i=num1; i<num2; i++)
    {
        for(int j=2; j<=i/2; j++)
        {
            if(i%j==0)
            {
                flag=1;
                break;
                
            }
            else 
            {
                System.out.println(i);
            }
        } 
            
        }
    }
