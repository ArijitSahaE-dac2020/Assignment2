package Day1;
class PyramidPattern5
{
	public static void main(String args[])
	{
		for(int i=1 ; i<=9 ; i++)
		{
			for(int j=9 ; j>=i ; j--)
			{
				System.out.print("  ");
				int c=10-i;
			}
			int c=10-i;
			for(int m=1 ; m<=i ; m++)
			{
				System.out.print(" "+c);
				c++;
			}
			int p=8;
			for(int k=2 ; k<=i ; k++)
			{
				System.out.print(" "+p);
				p--;
			}
			System.out.println();
		}
		
	}
}
