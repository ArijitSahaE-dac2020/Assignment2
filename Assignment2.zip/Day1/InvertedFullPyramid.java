package Day1;
class InvertedFullPyramid
{
    public static void main (String args[])
    {
        int rows=6;
        for(int i=1;i<=rows;i++)
        {
            for(int j=1;j<=i;j++)
            {
                System.out.print("   ");
            }
            for(int k=rows;k>=i;k--)
            {
                System.out.print(" * ");
            }
            for(int l=(rows-1);l>=i;l--)
            {
                System.out.print(" * ");
            }
            System.out.println();
        }
    }
}