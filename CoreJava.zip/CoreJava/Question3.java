package CoreJava;
import java.util.*;
class  Question3
{
  public static void main(String args[])
   {
      int  x=10, z=20;
      int y = (int) (Math.pow(x,2)) + 3*x - 7;
      System.out.println(y);
      y = x++ + ++x;
      System.out.println(y+ " "+x);
      z = x++ - --y - --x + x++ ;
           System.out.println(z);
           Question3 Bool= new Question3();
           Boolean Z = Bool.bool();
           
   }
   
boolean bool()
{
    boolean x= true,  y= true, z;
      z=(x && y) ||! (x || y);
      System.out.println(z);
      return z;
}
}
           
      
   


 