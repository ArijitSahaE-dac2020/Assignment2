package Lab_Assignment2;
public class ReverseNum
{

    public static void main(String[] args) 
    {

        int num = 43, reversed = 0;

        while (num != 0) 
        {
            int digit = num % 10;
            reversed = reversed * 10 + digit;
            num /= 10;
                    

        }
       
          System.out.println("Reversed Number: " + reversed);  

        
    }
}