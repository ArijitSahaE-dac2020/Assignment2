package CoreJava;
import java.util.*;
class  Question4
{
  public static void main(String args[])
   {
       Scanner sc = new Scanner(System.in);
       short y = sc.nextShort();
       byte x = (byte)y;
       System.out.println(x);
   }
}  