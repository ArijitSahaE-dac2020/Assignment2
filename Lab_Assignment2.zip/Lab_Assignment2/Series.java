package Lab_Assignment2;
import java.util.*; 

  
class Series 
{ 
// Function to find sum of series 
    public static void main(String a[])

{ 
  
	
        Scanner sc = new Scanner(System.in);
        
	System.out.println("Enter the upper bound=");
	
	int n=sc.nextInt();
          for(int i=12;  i<n; i++)
          {
              if(i%10==2)
              {
                  System.out.print(i+" + ");
              }
	}
}
} 

  