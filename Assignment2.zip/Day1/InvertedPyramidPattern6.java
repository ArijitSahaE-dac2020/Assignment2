package Day1;
class InvertedPyramidPattern6
{
    public static void main (String args[])
    {
        int rows=9;
        for(int i=1;i<=rows;i++)
        {
            for(int j=1;j<=i;j++)
            {
                System.out.print(" ");
            }
            for(int k=rows;k>=i;k--)
            {
                System.out.print("*");
            }
            for(int l=(rows-1);l>=i;l--)
            {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}