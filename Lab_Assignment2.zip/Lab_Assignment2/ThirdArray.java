package Lab_Assignment2;
import java.util.*;
public class ThirdArray

{
   
public static void main(String[] args) {
		
		Scanner sc  = new Scanner(System.in);
		System.out.println("enter the size of array:");
		int num=sc.nextInt();
		
		int arr[] = new int[num];
		
		int arr1[]=new int[num];
		int arr2[]=new int[num];
		System.out.println("1st array:");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
                System.out.println("2nd array:");
		for(int j=0;j<arr.length;j++)
		{
			arr1[j]=sc.nextInt();
		}
                 System.out.println("Sum of array:");
		for(int k=0;k<arr.length;k++)
		{
			arr2[k]=arr[k]+arr1[k];
			System.out.println(arr2[k]);
		}
	}
}

 